Script para decodar o config.bin do modem ZTE F670L da oi fibra

Testado em  firmware  ZTE F670L V9.0.11P1N3D

Você precisa instalar a lib zcu com: python setup.py install --user

Veja seu serial e mac no verso de seu modem e substitua na linha de comando abaixo
python oif670ldec.py config.bin --mac FC:40:09:2A:67:12 --serial ZTEGC4825060 decodado.xml



Comandos usados para desbloquear a ONT, você precisa pegar seu mac e serial no verso da ont

Decodificar o config.bin:
python oif670ldec.py config.bin --mac FC:40:09:2A:67:12 --serial ZTEGC4825060 config.xml

Codificar o config.bin
python oif670lenc.py --signature ZTE%FN$GponNJ025 --serial C482506012672a0940fc --use-signature-encryption config.xml config.bin


Rodar o exploit para ganhar telnet+root:
python3 zte_factroymode.py --user super --pass yQwjrtt2h25n --ip 192.168.100.1 --port 80 telnet open

Modificar a ONT para manufacture(chinesa), nao se preocupe , o texto fica em ingles
upgradetest sfactoryconf 198


@kidling, dezembro de  2023 
Baseado em  https://github.com/mkst/zte-config-utility
e em https://github.com/douniwan5788/zte_modem_tools