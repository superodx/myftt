---
name: Feature request
about: Suggest an idea for this project, e.g. new device support
title: "[FEATURE]"
labels: ''
assignees: ''

---

**Description of new feature**
e.g. I would like the ZTE 1234 XYZ v2.5 router to be supported

**Describe alternatives you've considered**
e.g. I have tried using --payload xxx but I get the following error < error >

**Additional context**
Add any other context or screenshots about the feature request here.

**Attach config.bin for your device**
Optional, but will help anyone trying to add support for the device.
